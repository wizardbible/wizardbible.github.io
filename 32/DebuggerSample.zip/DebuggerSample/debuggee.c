#define _WIN32_WINNT	0x0400
#include <windows.h>
#pragma comment(lib, "user32.lib")

int WINAPI WinMain
(HINSTANCE hInstance, HINSTANCE hPrev, LPSTR pszCmdLine, int iShowCmd)
{
	__try
	{
		RaiseException(EXCEPTION_BREAKPOINT, 0, 0, 0);
	}
	__except(EXCEPTION_EXECUTE_HANDLER)
	{
		MessageBox(NULL, "No debugger is attached!", "info", MB_OK);
		if( IsDebuggerPresent() )
		{
			MessageBox(NULL
			,	"IsDebuggerPresent() returned TRUE.", "info", MB_OK);
		}
		else
		{
			MessageBox(NULL
			,	"IsDebuggerPresent() returned FALSE.", "info", MB_OK);
		}
		return 0;
	}
	
	MessageBox(NULL, "Debugger is attached!", "info", MB_OK);
	return 1;
}

