#pragma once
#ifdef __cplusplus
extern "C" {
#endif

void ShowError(const char* pszFormat, ...);
void ShowMessage(const char* pszFormat, ...);

#ifdef __cplusplus
}
#endif
