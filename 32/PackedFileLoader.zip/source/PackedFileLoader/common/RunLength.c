#include <windows.h>
#include <stdio.h>
#include "RunLength.h"

// n �Ԗڂ� bit �𗧂Ă������� x |= FLAG_TABLE[n % 8]��
// �ł���悤�ɂ���e�[�u��
static const BYTE FLAG_TABLE[8] =
{
	0x80, 0x40, 0x20, 0x10, 0x08, 0x04, 0x02, 0x01
};

// ���̃r�b�g��
#define LENGTH_BITS		5
// ���̍ő�l(1��0�A2��1�E�E�E)
#define LENGTH_MAX		(1 << LENGTH_BITS)

// �r�b�g�P�ʂ�I/O���s�����߂̍\����
typedef struct
{
	LPBYTE	pBuffer;
	DWORD	dwBufferSize;
	DWORD	dwIndex;
} BITIO;

// �r�b�g�P�ʂł̏������݁BdwWriteData �̉��� dwBitCount �r�b�g����������
static BOOL BitWrite(BITIO* io_pbio, DWORD i_dwWriteData, DWORD i_dwBitCount)
{
	DWORD dwWriteData = i_dwWriteData << (sizeof(DWORD) * 8 - i_dwBitCount);
	DWORD MSB = 1 << (sizeof(DWORD) * 8 - 1);	// 0x80000000
	DWORD i;
	
	// �������s��
	if( io_pbio == NULL
	||	io_pbio->pBuffer == NULL
	||	i_dwBitCount == 0
	||	i_dwBitCount > sizeof(DWORD) * 8 )
	{
		SetLastError(ERROR_BAD_ARGUMENTS);
		return FALSE;
	}

	// �o�b�t�@�T�C�Y�̃`�F�b�N
	if( io_pbio->dwBufferSize < (i_dwBitCount + io_pbio->dwIndex + 7) / 8 )
	{
		SetLastError(ERROR_NOT_ENOUGH_MEMORY);
		return FALSE;
	}

	for(i = 0; i < i_dwBitCount; i++)
	{
		if( MSB & dwWriteData )
		{
			io_pbio->pBuffer[(io_pbio->dwIndex + i) / 8]
			|=	FLAG_TABLE[(io_pbio->dwIndex + i) % 8];
		}
		else
		{
			io_pbio->pBuffer[(io_pbio->dwIndex + i) / 8]
			&=	~FLAG_TABLE[(io_pbio->dwIndex + i) % 8];
		}
		dwWriteData <<= 1;
	}

	io_pbio->dwIndex += i_dwBitCount;
	return TRUE;
}

// �r�b�g�P�ʂł̓ǂݍ��݁B���� dwBitCount �r�b�g��ǂݍ���
static BOOL BitRead(BITIO* io_pbio, DWORD* i_pdwOut, DWORD i_dwBitCount)
{
	DWORD dwOut = 0;
	DWORD i = 0;

	// �����`�F�b�N
	if( io_pbio == NULL
	||	io_pbio->pBuffer == NULL
	||	i_dwBitCount == 0
	||	i_dwBitCount > sizeof(DWORD) * 8 )
	{
		SetLastError(ERROR_BAD_ARGUMENTS);
		return FALSE;
	}

	// �o�b�t�@�T�C�Y�̃`�F�b�N
	if( io_pbio->dwBufferSize < (i_dwBitCount + io_pbio->dwIndex + 7) / 8 )
	{
		SetLastError(ERROR_NOT_ENOUGH_MEMORY);
		return FALSE;
	}

	for(i = 0; i < i_dwBitCount; i++)
	{
		dwOut <<= 1;
		if( io_pbio->pBuffer[(io_pbio->dwIndex + i) / 8]
			& FLAG_TABLE[(io_pbio->dwIndex + i) % 8] )
		{
			dwOut |= 1;
		}
	}

	*i_pdwOut = dwOut;
	io_pbio->dwIndex += i_dwBitCount;
	return TRUE;
}

// ���k�����ۂ̃T�C�Y���擾����
DWORD RunLengthGetSize(LPBYTE i_pData, DWORD i_dwBytes)
{
	DWORD dwEncodedSize = 0;
	SIZE_T i = 0;
	DWORD dwBitCount = 0;
	
	// �����`�F�b�N
	if( i_pData == NULL || i_dwBytes == 0 )
	{
		SetLastError(ERROR_BAD_ARGUMENTS);
		return 0;
	}

	while( i < i_dwBytes )
	{
		SIZE_T j = i + 1;
		DWORD  dwLength = 0;
		while( j < i_dwBytes && i_pData[i] == i_pData[j] && dwLength < LENGTH_MAX )
		{
			j++;
			dwLength++;
		}
		
		dwBitCount += 1 + 8 + (dwLength ? LENGTH_BITS : 0);
		i = j;
	}
	
	return (dwBitCount + 7) / 8;
}


// ���k
DWORD RunLengthEncode(LPBYTE i_pData, DWORD i_dwBytes, PRUNLENGTH* o_pprl)
{
	DWORD dwEncodedSize = 0;
	SIZE_T i = 0;
	BITIO bio;
	PRUNLENGTH prl = NULL;

	// �����`�F�b�N
	if( i_pData == NULL || i_dwBytes == 0 || o_pprl == NULL )
	{
		SetLastError(ERROR_BAD_ARGUMENTS);
		return 0;
	}

	// �\�߈��k�ς݂̃T�C�Y���擾
	dwEncodedSize = RunLengthGetSize(i_pData, i_dwBytes);
	if( dwEncodedSize == 0 ) return 0;

	// ���������m��
	prl = (PRUNLENGTH)calloc(dwEncodedSize + sizeof(DWORD), sizeof(BYTE));
	if( prl == NULL )
	{
		SetLastError(ERROR_NOT_ENOUGH_MEMORY);
		return 0;
	}

	// ���̃T�C�Y��ۑ�
	prl->dwOriginalSize = i_dwBytes;
	// BITIO �Ƀf�[�^���Z�b�g
	bio.pBuffer = prl->abytData;
	bio.dwBufferSize = dwEncodedSize;
	bio.dwIndex = 0;
	
	while(i < i_dwBytes)
	{
		SIZE_T j = i + 1;
		DWORD  dwLength = 0;
		while( j < i_dwBytes && i_pData[i] == i_pData[j] && dwLength < LENGTH_MAX )
		{
			j++;
			dwLength++;
		}
		
		if( dwLength )
		{
			BitWrite(&bio, 1, 1);
			BitWrite(&bio, i_pData[i], 8);
			BitWrite(&bio, dwLength - 1, LENGTH_BITS);
		}
		else
		{
			BitWrite(&bio, 0, 1);
			BitWrite(&bio, i_pData[i], 8);
		}

		i = j;
	}

	*o_pprl = prl;
	return dwEncodedSize;
}


// RunLengthEncode() �Ŋm�ۂ����������̉��
BOOL RunLengthDestroy(PRUNLENGTH* io_pprl)
{
	if( io_pprl && *io_pprl)
	{
		free(*io_pprl);
		*io_pprl = NULL;
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

// �W�J
DWORD RunLengthDecode
(LPBYTE o_pBuffer, DWORD i_dwBufferSize, PRUNLENGTH i_prl, DWORD i_dwDataSize)
{
	BITIO bio = { 0 };
	SIZE_T i = 0, j = 0;

	// �����`�F�b�N
	if( o_pBuffer == NULL || i_dwBufferSize == 0
	|| i_prl == NULL || i_prl->dwOriginalSize == 0
	|| i_dwDataSize == 0 )
	{
		SetLastError(ERROR_BAD_ARGUMENTS);
		return 0;
	}

	// �o�b�t�@�T�C�Y�̃`�F�b�N
	if( i_dwBufferSize < i_prl->dwOriginalSize )
	{
		SetLastError(ERROR_NOT_ENOUGH_MEMORY);
		return 0;
	}

	bio.pBuffer = i_prl->abytData;
	bio.dwBufferSize = i_dwDataSize;
	bio.dwIndex = 0;
	while( i < i_prl->dwOriginalSize )
	{
		DWORD dwFlag = 0, dwCode = 0, dwLength = 1;
		BitRead(&bio, &dwFlag, 1);
		BitRead(&bio, &dwCode, 8);
		if( dwFlag )
		{
			BitRead(&bio, &dwLength, LENGTH_BITS);
			dwLength += 2;	// code/0based
		}
		
		for(j = 0; j < dwLength && (i + j) < i_prl->dwOriginalSize; j++)
		{
			o_pBuffer[i + j] = (BYTE)dwCode;
		}
		
		i += j;
	}
	
	return i_prl->dwOriginalSize;
}


#if 0
int main()
{
	{
		BYTE data[200];
		BITIO bio = { data, 200, 0 };
		DWORD dwRead = 0;

		printf("%d\n", BitWrite(&bio, 1, 1));
		BitWrite(&bio, 0x56, 8);
		BitWrite(&bio, 0xD, 5);
		printf("%02X,%02X\n", data[0], data[1]);

		bio.dwIndex = 0;
		BitRead(&bio, &dwRead, 1);
		printf("%02X,", dwRead);
		BitRead(&bio, &dwRead, 8);
		printf("%02X,", dwRead);
		BitRead(&bio, &dwRead, 5);
		printf("%02X\n", dwRead);
	}

	{
		char sz[] = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaabbccbbabcbaaa";
		PRUNLENGTH prl = NULL;
		SIZE_T uEncodedSize = RunLengthEncode((LPBYTE)sz, strlen(sz) + 1, &prl);
		char szEncoded[sizeof sz];
		printf("%d, %d\n", prl->dwOriginalSize, strlen(sz) + 1);
		printf("%dbyte �� %dbyte\n", strlen(sz), uEncodedSize);
		RunLengthDecode(szEncoded, sizeof szEncoded, prl, uEncodedSize);
		printf("%d, %s\n", strcmp(sz, szEncoded), szEncoded);
		
		{	SIZE_T i;
			for(i = 0; i < uEncodedSize; i++)
			{
				printf("%02X", prl->abytData[i]);
			}
		}
	}
	return 0;
}
#endif

