#include <windows.h>
#include <stdio.h>
#include <stdarg.h>

void ShowError(const char* pszFormat, ...)
{
	char szMessage[1024];
	va_list val;
	va_start(val, pszFormat);
	_vsnprintf(szMessage, sizeof szMessage, pszFormat, val);
	va_end(val);
	MessageBox(NULL, szMessage, "Error", MB_ICONEXCLAMATION);
}


void ShowMessage(const char* pszFormat, ...)
{
	char szMessage[1024];
	va_list val;
	va_start(val, pszFormat);
	_vsnprintf(szMessage, sizeof szMessage, pszFormat, val);
	va_end(val);
	MessageBox(NULL, szMessage, "Error", MB_OK);
}

