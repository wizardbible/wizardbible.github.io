
#include <cstdio>
#include "ZLoaderCreator.h"

CZLoader::CZLoader()
{
}

CZLoader::~CZLoader()
{
}

bool CZLoader::Load()
{
	return pe.LoadPE( "ZLoader.exe" );
}

bool CZLoader::Build(const LoaderInfo &info, DWORD vaddr)
{
	PIMAGE_NT_HEADERS nthdr = pe.GetNtHeaders();
	if ( nthdr == NULL ||  nthdr->FileHeader.NumberOfSections < 2 ) {
		return false;
	}

	// �R�[�h�Z�N�V�����̎擾
	PIMAGE_SECTION_HEADER code = pe.ConvertRvaToSection( nthdr->OptionalHeader.AddressOfEntryPoint );
	if ( code == NULL ) {
		return false;
	}

	// .reloc�Z�N�V�����̌���
	DWORD i = 0;
	PIMAGE_SECTION_HEADER sec, reloc;
	sec = reloc = NULL;
	while ( (sec = pe.GetSectionHeader(i++)) != NULL && reloc == NULL ) {
		if ( memcmp(sec->Name, ".reloc", 6) == 0 ) {
			reloc = sec;
		}
	}
	if ( reloc == NULL ) {
		return false;
	}

	// �T�C�Y�̃`�F�b�N
	DWORD codesize = min( code->SizeOfRawData, code->Misc.VirtualSize );
	if ( pe.GetSize() < code->PointerToRawData + codesize ) {
		return false;
	}
	DWORD relocsize = min( reloc->SizeOfRawData, reloc->Misc.VirtualSize );
	if ( pe.GetSize() < reloc->PointerToRawData + relocsize ) {
		return false;
	}

	// �A�h���X�̏��������i�Z�N�V�����̍Ĕz�u�j
	BYTE *codedata  = pe.GetImage() + code->PointerToRawData;
	BYTE *relocdata = pe.GetImage() + reloc->PointerToRawData;
	relocate( codedata, relocdata, code->VirtualAddress, vaddr );

#if 0
#ifdef _DEBUG
	printf( "\n" );
	printf( "DEBUG PRINT CZLoader\n" );
	printf( "ImageBase:            %x\n", nthdr->OptionalHeader.ImageBase );
	printf( "Code.VirtualAddresss: %x\n", code->VirtualAddress );
	printf( "Fixed.VirtualAddress: %x\n", vaddr );
	printf( "\n" );
#endif
#endif

	// �󂯓n���\���̂��R�s�[����
	memcpy( codedata, &info, sizeof(info) );

	return true;
}
