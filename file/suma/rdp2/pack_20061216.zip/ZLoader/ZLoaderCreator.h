
#pragma once

#include "../LoaderCreator.h"

class CZLoader : public CLoaderCreator
{
public:
	CZLoader();
	~CZLoader();
	bool Load();
	bool Build(const LoaderInfo &info, DWORD vaddr);

	// For test.cpp
	DWORD GetImageBase()
	{
		PIMAGE_NT_HEADERS nthdr = pe.GetNtHeaders();
		if ( nthdr == NULL ) {
			return 0;
		}
		return nthdr->OptionalHeader.ImageBase;
	}
};