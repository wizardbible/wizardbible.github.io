
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include "../Loader.h"
#include "../LoaderInfo.h"
#include "../zlib/zlib.h"

#pragma comment(linker, "/entry:\"main\"")
#pragma comment(linker, "/NODEFAULTLIB")

#pragma comment(linker, "/merge:.data=.text")
#pragma comment(linker, "/merge:.rdata=.text")


typedef void * (WINAPI *f_GlobalAlloc)(UINT, SIZE_T) ;
typedef void   (WINAPI *f_GlobalFree)(void *);


static LoaderInfo LInfo = { 0x44332211, 0x88776655 };
static f_GlobalAlloc p_GlobalAlloc;
static f_GlobalFree  p_GlobalFree;


void * _cdecl malloc(size_t size)
{
	return p_GlobalAlloc( GMEM_FIXED, size );
}

void _cdecl free(void *p)
{
    p_GlobalFree( p );
} 

void __stdcall InitAPIAddress(HMODULE addr)
{
	p_GlobalAlloc = (f_GlobalAlloc)MyGetProcAddress( addr, "GlobalAlloc" );
	p_GlobalFree  = (f_GlobalFree)MyGetProcAddress( addr, "GlobalFree" );
}

DWORD_PTR __stdcall unpack(DWORD_PTR kernel_return_address)
{
	HMODULE hKernel;

	hKernel = LoadKernel( kernel_return_address );
	if ( hKernel == NULL ) {
		return NULL;
	}

	InitAPIAddress( hKernel );

	if ( uncompress(LInfo.CodeAddress, &LInfo.CodeLength, LInfo.DataAddress, LInfo.DataLength) != Z_OK ) {
		return NULL;
	}

	return LInfo.CodeEntryPoint;
}

void __declspec(naked) main()
{
	_asm {
		PUSH  [ESP]
		CALL  [unpack]
		TEST  EAX, EAX
		JZ    END
		JMP   EAX
END:
		RET
	}
}


