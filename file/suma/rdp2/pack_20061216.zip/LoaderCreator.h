
#pragma once

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "PackLib/PackLib.h"
#include "LoaderInfo.h"

class CLoaderCreator
{
protected:
	PE pe;
public:
	CLoaderCreator();
	virtual ~CLoaderCreator();

	virtual bool Load() = 0;
	DWORD GetSize();
	DWORD GetEntryPoint();
	const BYTE * GetCode();

protected:
	void relocate(unsigned char *data, unsigned char *reloc, DWORD_PTR oldbase, DWORD_PTR newbase);

};
