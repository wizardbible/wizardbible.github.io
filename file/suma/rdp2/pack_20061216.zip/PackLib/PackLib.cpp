#include <algorithm>
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <fstream>

#include "PackLib.h"


using namespace std;

PE::PE()
	: m_image( NULL ), m_size( 0 )
{
}

PE::~PE()
{
	Close();
}

void  PE::Realloc(DWORD size)
{
	if ( !IsOpened() ) {
		return;
	}
	if ( m_size < size ) {
		BYTE *p = new BYTE[size];
		memcpy( p, m_image, m_size );
		delete [] m_image;
		m_image = p;
	}
	m_size = size;
}

bool PE::IsOpened()
{
	return m_image != NULL ? true : false;
}

bool PE::LoadPE(const TCHAR *file)
{
	Close();

	ifstream fs( file, ios::binary );
	if ( !fs ) {
		return false;
	}

	// get filesize
	fs.seekg( 0, ios::end );
	m_size = fs.tellg();
	fs.seekg( 0, ios::beg );

	// allocate
	m_image = new BYTE[m_size];

	// read
	fs.read( (char*)m_image, m_size );

	// check size and signature
	if ( !CheckPEHeader() ) {
		Close();
		return false;
	}

	return true;
}

void PE::Close()
{
	delete [] m_image;
	m_image = NULL;
	m_size = 0;
}


PIMAGE_NT_HEADERS PE::GetNtHeaders()
{
	if ( !IsOpened() ) {
		return NULL;
	}

	if ( m_size < sizeof(IMAGE_DOS_HEADER) ) {
		return NULL;
	}

	PIMAGE_DOS_HEADER doshdr = (PIMAGE_DOS_HEADER)m_image;
	if ( doshdr->e_magic != IMAGE_DOS_SIGNATURE || doshdr->e_lfanew < 0 ||
		m_size < (doshdr->e_lfanew + sizeof(IMAGE_NT_HEADERS)) )
	{
		return NULL;
	}

	PIMAGE_NT_HEADERS nthdr = (PIMAGE_NT_HEADERS)(m_image + doshdr->e_lfanew);
	if ( nthdr->Signature != IMAGE_NT_SIGNATURE ) {
		return NULL;
	}

	return nthdr;
}

bool PE::CheckPEHeader()
{
	if ( GetNtHeaders() == NULL ) {
		return false;
	}

	if ( m_size <
		PIMAGE_DOS_HEADER(m_image)->e_lfanew + sizeof(IMAGE_NT_HEADERS) +
		GetNtHeaders()->FileHeader.NumberOfSections * sizeof(IMAGE_SECTION_HEADER) )
	{
		return false;
	}

	return true;
}

PIMAGE_SECTION_HEADER PE::GetSectionHeader(DWORD num)
{
	PIMAGE_NT_HEADERS nthdr = GetNtHeaders();
	if ( nthdr == NULL || nthdr->FileHeader.NumberOfSections < num + 1 ) {
		return NULL;
	}

	PIMAGE_SECTION_HEADER sechdr = (PIMAGE_SECTION_HEADER)(nthdr + 1);

	DWORD_PTR diff = (DWORD_PTR)sechdr - (DWORD_PTR)m_image;
	if ( m_size < diff + sizeof(IMAGE_SECTION_HEADER) * (num + 1) ) {
		return NULL;
	}

	return sechdr + num;
}

struct FindRVA {
	FindRVA(DWORD r) { rva =r; }
	DWORD rva;
	bool operator()(const PIMAGE_SECTION_HEADER s) const
	{
		if ( s->VirtualAddress <= rva && rva < s->VirtualAddress + s->Misc.VirtualSize ) {
			return true;
		}
		return false;
	}
};

PIMAGE_SECTION_HEADER PE::ConvertRvaToSection(DWORD rva)
{
	return FindSectionHeader( FindRVA(rva) );
}

template<typename T> 
PIMAGE_SECTION_HEADER PE::FindSectionHeader(const T &func)
{
	PIMAGE_SECTION_HEADER sechdr;
	DWORD i = 0;
	while ( (sechdr = GetSectionHeader(i++)) != NULL ) {
		if ( func(sechdr) ) {
			return sechdr;
		}
	}

	return NULL;
}

struct RvaOfBegin {
	DWORD operator()(const PIMAGE_SECTION_HEADER hdr, DWORD r) const
	{
		return min( hdr->VirtualAddress, r );
	}
};

struct RvaOfEnd {
	DWORD operator()(const PIMAGE_SECTION_HEADER hdr, DWORD r) const
	{
		return max( hdr->VirtualAddress + hdr->Misc.VirtualSize, r );
	}
};

struct OffsetOfBegin {
	DWORD operator()(const PIMAGE_SECTION_HEADER hdr, DWORD r) const
	{
		return min( hdr->PointerToRawData, r );
	}
};

struct OffsetOfEnd {
	DWORD operator()(const PIMAGE_SECTION_HEADER hdr, DWORD r) const
	{
		return max( hdr->PointerToRawData + hdr->SizeOfRawData, r );
	}
};

template<typename T>
DWORD PE::FindSectionHeader(const T &func, DWORD x)
{
	PIMAGE_SECTION_HEADER sechdr;
	DWORD i = 0;
	while ( (sechdr = GetSectionHeader(i++)) != NULL ) {
		x = func( sechdr, x );
	}

	return x;
}

DWORD PE::GetEndOfRva()
{
	return FindSectionHeader( RvaOfEnd(), 0 );
}

DWORD PE::GetEndOfOffset()
{
	return FindSectionHeader( OffsetOfEnd(), 0 );
}

PEGenerator::PEGenerator()
{
}

PEGenerator::~PEGenerator()
{
}

bool PEGenerator::AddSectionHeader(PIMAGE_SECTION_HEADER sechdr)
{
	PIMAGE_NT_HEADERS nthdr = GetNtHeaders();
	if ( nthdr == NULL || sechdr == NULL) {
		return false;
	}

	DWORD secfront = CalculateAlign( GetEndOfOffset(), nthdr->OptionalHeader.FileAlignment );
	DWORD secvafront = CalculateAlign( GetEndOfRva(), nthdr->OptionalHeader.SectionAlignment );

	sechdr->PointerToRawData = secfront;
	sechdr->VirtualAddress = secvafront;

	if ( sechdr->SizeOfRawData != 0 ) {
		DWORD newsize = CalculateAlign( secfront + sechdr->SizeOfRawData, nthdr->OptionalHeader.FileAlignment );
		if ( newsize == 0 ) {
			return false;
		}
		Realloc( newsize );
		memset( m_image + secfront, 0, newsize - secfront );

		nthdr = GetNtHeaders();
	}

	// ���݂���Z�N�V�����w�b�_�̎��̃A�h���X���擾
	PIMAGE_SECTION_HEADER newsec = GetSectionHeader( nthdr->FileHeader.NumberOfSections - 1 );
	if ( newsec == NULL ) {
		return false;
	}
	newsec++;

	// �w�b�_�̃R�s�[
	memcpy( newsec, sechdr, sizeof(IMAGE_SECTION_HEADER) );

	// �Z�N�V�����̐����X�V
	nthdr->FileHeader.NumberOfSections++;

	// �Z�N�V�����ǉ��ɂ��T�C�Y�i���ۂ̃t�@�C���T�C�Y�ł͂Ȃ��j�̕ύX
	nthdr->OptionalHeader.SizeOfImage = CalculateAlign( sechdr->VirtualAddress + sechdr->Misc.VirtualSize, nthdr->OptionalHeader.SectionAlignment );

	return true;
}

bool PEGenerator::AddSection(PIMAGE_SECTION_HEADER sechdr, const void *data, DWORD size)
{
	if ( sechdr == NULL || GetNtHeaders() == NULL || data == NULL || size == 0 ) {
		return false;
	}

	if ( GetSize() < sechdr->PointerToRawData + size ) {
		return false;
	}

	if ( !AddSectionHeader(sechdr ) ) {
		return false;
	}

	memcpy( GetImage() + sechdr->PointerToRawData, data, size );

	return true;
}

bool PEGenerator::ReduceSectionSize(DWORD num, DWORD rsize)
{
	return ReduceSectionSize( GetSectionHeader(num), rsize );
}

// �Z�N�V�����̃T�C�Y�����T�C�Y�i�������j����
bool PEGenerator::ReduceSectionSize(PIMAGE_SECTION_HEADER target, DWORD rsize)
{
	if ( target == NULL ) {
		return false;
	}
	if ( rsize >= target->SizeOfRawData || GetSize() < (target->SizeOfRawData + rsize) ) {
		return false;
	}

	DWORD decsize = target->SizeOfRawData - rsize;

	PIMAGE_SECTION_HEADER sec;
	DWORD i = 0;
	while ( (sec = GetSectionHeader(i++)) != NULL ) {
		if ( sec->PointerToRawData > target->PointerToRawData ) {
			sec->PointerToRawData -= decsize;
		}
	}

	BYTE *data = GetImage() + target->PointerToRawData;
	memmove( data,
	         data + target->SizeOfRawData,
	         GetSize() + rsize - (target->PointerToRawData + target->SizeOfRawData)
	       );

	SetSize( GetSize() - rsize );

	if ( rsize == 0 ) {
		target->PointerToRawData = 0;
	}
	target->SizeOfRawData = rsize;

	return true;
}

// �A���C�����g�̌v�Z���s��
DWORD CalculateAlign(DWORD digit, DWORD align)
{
	return (digit + align - 1) / align * align;
}

