
#pragma once

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

class PE
{
protected:
	BYTE* m_image;
	DWORD m_size;

	PE(const PE&);
	PE & operator=(const PE&);

public:
	PE();
	virtual ~PE();

	BYTE* GetImage() { return m_image; }
	DWORD GetSize() { return m_size; }
	void  SetSize(DWORD size) { m_size = size; }
	void  Realloc(DWORD size);

	bool IsOpened();
	bool LoadPE(const TCHAR *file);
	void Close();
	PIMAGE_NT_HEADERS GetNtHeaders();

	PIMAGE_SECTION_HEADER GetSectionHeader(DWORD num);	// 0�`
	PIMAGE_SECTION_HEADER ConvertRvaToSection(DWORD rva);

	template<typename T> PIMAGE_SECTION_HEADER FindSectionHeader(const T &);
	template<typename T> DWORD FindSectionHeader(const T &, DWORD x);

	DWORD GetEndOfRva();
	DWORD GetEndOfOffset();

private:
	bool CheckPEHeader();

};

class PEGenerator : public PE
{
public:
	PEGenerator();
	virtual ~PEGenerator();

	bool AddSectionHeader(PIMAGE_SECTION_HEADER sechdr);
	bool AddSection(PIMAGE_SECTION_HEADER sechdr, const void *data, DWORD size);
	bool ReduceSectionSize(DWORD num, DWORD rsize);
	bool ReduceSectionSize(PIMAGE_SECTION_HEADER target, DWORD rsize);

};


DWORD CalculateAlign(DWORD digit, DWORD align);

