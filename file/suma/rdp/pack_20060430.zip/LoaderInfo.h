
#pragma once

typedef struct {
	DWORD_PTR DataAddress;
	DWORD     DataLength;
	DWORD_PTR CodeAddress;
	DWORD     CodeLength;
	DWORD_PTR CodeEntryPoint;
} LoaderInfo;

