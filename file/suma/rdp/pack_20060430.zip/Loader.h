
#pragma once

#define db _asm _emit

#define STR_VIRTUALALLOC db 'V' db 'i' db 'r' db 't' db 'u' db 'a' db 'l' db 'A' db 'l' db 'l' db 'o' db 'c' db 0
#define STR_VIRTUALFREE  db 'V' db 'i' db 'r' db 't' db 'u' db 'a' db 'l' db 'F' db 'r' db 'e' db 'e' db 0
#define STR_GLOBALALLOC  db 'G' db 'l' db 'o' db 'b' db 'a' db 'l' db 'A' db 'l' db 'l' db 'o' db 'c' db 0
#define STR_GLOBALFREE   db 'G' db 'l' db 'o' db 'b' db 'a' db 'l' db 'F' db 'r' db 'e' db 'e' db 0



#undef MakePtr
#define MakePtr(cast, base, offset) (cast)((DWORD_PTR)(base) + (DWORD_PTR)(offset))
#define NTH(hLib) ( (PIMAGE_NT_HEADERS)( (LPBYTE)hLib + (((PIMAGE_DOS_HEADER)(hLib))->e_lfanew) ) )
#define RVA(hLib) (NTH(hLib)->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress)

#define EXPDIR(hLib) (MakePtr( PIMAGE_EXPORT_DIRECTORY, hLib, RVA(hLib)))

#define ADDRTBL(hLib) (MakePtr(LPDWORD, hLib, EXPDIR(hLib)->AddressOfFunctions))
#define ORDNTBL(hLib) (MakePtr(LPWORD, hLib, EXPDIR(hLib)->AddressOfNameOrdinals))



FARPROC __stdcall MyGetProcAddress(HMODULE mod, const char *procname)
{
	// Export Address Table
	LPDWORD eat = MakePtr( LPDWORD, mod, EXPDIR(mod)->AddressOfFunctions );
	// Export Ordinal Table
	LPWORD  eot = MakePtr(  LPWORD, mod, EXPDIR(mod)->AddressOfNameOrdinals );
	// Export Name Table
	LPDWORD ent = MakePtr( LPDWORD, mod, EXPDIR(mod)->AddressOfNames );

	int i, num;
	for ( i = 0, num = (int)EXPDIR(mod)->NumberOfNames; i < num; i++ ) {
		char *expname = MakePtr( char*, mod, ent[i] );
		if ( strcmp(procname, expname) == 0 ) {
			return MakePtr( FARPROC, mod, eat[ eot[i] ] );
		}
	}

	return NULL;
}


int __stdcall CheckPEHeader(DWORD_PTR addr)
{
	PIMAGE_DOS_HEADER dosh = (PIMAGE_DOS_HEADER)addr;
	if ( dosh->e_magic == IMAGE_DOS_SIGNATURE && ((PIMAGE_NT_HEADERS)(addr+dosh->e_lfanew))->Signature == IMAGE_NT_SIGNATURE ) {
		return 1;
	}
	return 0;
}

HMODULE __stdcall LoadKernel(DWORD_PTR addr)
{
	for ( addr &= 0xFFFF0000; addr > 0x7000000; addr -= 0x10000 ) {
		if ( CheckPEHeader(addr) ) {
			return (HMODULE)addr;
		}
	}
	return NULL;
}

