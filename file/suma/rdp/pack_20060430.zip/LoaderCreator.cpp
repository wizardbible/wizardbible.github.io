
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "LoaderCreator.h"
#include <cstdio>
#include <cstdlib>

CLoaderCreator::CLoaderCreator()
{
}

CLoaderCreator::~CLoaderCreator()
{
}

// ���[�_�[�̃T�C�Y��Ԃ�
DWORD CLoaderCreator::GetSize()
{
	PIMAGE_NT_HEADERS nthdr = pe.GetNtHeaders();
	if ( nthdr == NULL ) {
		return 0;
	}

	PIMAGE_SECTION_HEADER code = pe.ConvertRvaToSection( nthdr->OptionalHeader.AddressOfEntryPoint );
	if ( code == NULL ) {
		return NULL;
	}

	return min( code->SizeOfRawData, code->Misc.VirtualSize );
}

// ���[�_�[�̃G���g���[�|�C���g�̃I�t�Z�b�g�iAddressOfEntryPoint - VirtualAddress)��Ԃ�
DWORD CLoaderCreator::GetEntryPoint()
{
	PIMAGE_NT_HEADERS nthdr = pe.GetNtHeaders();
	if ( nthdr == NULL ) {
		return 0;
	}

	PIMAGE_SECTION_HEADER code = pe.ConvertRvaToSection( nthdr->OptionalHeader.AddressOfEntryPoint );
	if ( code == NULL ) {
		return NULL;
	}

	return nthdr->OptionalHeader.AddressOfEntryPoint - code->VirtualAddress;
}

// ���[�_�[�̃R�[�h�ւ̃|�C���^��Ԃ�
const BYTE * CLoaderCreator::GetCode()
{
	PIMAGE_NT_HEADERS nthdr = pe.GetNtHeaders();
	if ( nthdr == NULL ) {
		return 0;
	}

	PIMAGE_SECTION_HEADER code = pe.ConvertRvaToSection( nthdr->OptionalHeader.AddressOfEntryPoint );
	return pe.GetImage() + code->PointerToRawData;
}

// �Ĕz�u�Z�N�V�������g���ăA�h���X������������
void CLoaderCreator::relocate(
	unsigned char *data,
	unsigned char *reloc,
	DWORD_PTR oldbase,
	DWORD_PTR newbase)
{
	DWORD delta = newbase - oldbase;
	DWORD i;

	while (*(PDWORD)reloc) {
		DWORD base =  *(PDWORD) reloc - oldbase;
		DWORD size = (*(PDWORD)(reloc + 4) - 8) >> 1;
		reloc += 8;
		for (i = 0; i < size; ++i, reloc += 2) {
			struct REL {			// [type:4][ofs:12]
				unsigned ofs:12;
				unsigned type:4;
			} *rel = (REL*)reloc;
			switch (rel->type) {
			case IMAGE_REL_BASED_HIGH:    *(PWORD) (data + base + rel->ofs) += HIWORD(delta); break;
			case IMAGE_REL_BASED_LOW:     *(PWORD) (data + base + rel->ofs) += LOWORD(delta); break;
			case IMAGE_REL_BASED_HIGHLOW: *(PDWORD)(data + base + rel->ofs) += delta; break;
			case IMAGE_REL_BASED_HIGHADJ: printf("IMAGE_REL_BASED_HIGHADJ IS NOT SUPPORTED"); abort();	// �����A�Ȃ�̂��Ƃ�����`�H
			}
		}
	}
}
