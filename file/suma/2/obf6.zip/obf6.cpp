#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <cstdio>
#include <cstdlib>
#include <memory>

extern "C" {
#include "./libdisasm/src/libdis.h"
}


typedef int (WINAPI *f_MessageBox)(HWND, LPCTSTR, LPCTSTR, UINT);
HINSTANCE hUser = NULL;
f_MessageBox p_MessageBoxA = NULL;
BYTE *stub_MessageBoxA = NULL;



DWORD CopyCode(BYTE *buf, BYTE *dest, DWORD maxsize);
void WriteJump(BYTE *buf, DWORD address);
void LoadAPI();


DWORD CopyCode(BYTE *buf, BYTE *dest, DWORD maxsize)
{
	DWORD pos;
	x86_init( opt_none, NULL );

	for ( pos = 0; pos < maxsize ; ) {
		x86_insn_t insn;
		int size = x86_disasm( buf, maxsize, 0, pos, &insn );
		if ( size + pos <= maxsize && size ) {
			if ( insn.group == insn_controlflow ) {
				if ( insn.type == insn_jmp || insn.type == insn_jcc ||
					insn.type ==  insn_call || insn.type == insn_loop ) {
					break;
				}
			}
			memcpy( dest + pos, buf + pos, size );
			pos += size;
		} else {
			break;
		}
	}
	x86_cleanup();
	return pos;
}


void WriteJump(BYTE *buf, DWORD address)
{
	*buf = 0xE9;	// ����JMP

	*(DWORD*)(buf+1) = address - (DWORD)buf - 5;
}

void InitAPI()
{
	hUser = LoadLibrary("user32.dll");
	if ( hUser == NULL ) {
		printf("failed: Loading User32.dll");
		exit( 1 );
	}
	p_MessageBoxA = (f_MessageBox)GetProcAddress( hUser, "MessageBoxA" );
	if ( p_MessageBoxA == NULL ) {
		printf( "failed: GetProcAddress" );
		exit( 1 );
	}

	const int JUMP_SIZE = 5, MAX_COPY_SIZE = 15;
	stub_MessageBoxA = (BYTE*)VirtualAlloc( NULL, MAX_COPY_SIZE + JUMP_SIZE, MEM_COMMIT,PAGE_EXECUTE_READWRITE );
	if ( stub_MessageBoxA == NULL ) {
		printf( "failed: VirtualAlloc" );
		exit( 1 );
	}

	DWORD copied = CopyCode( (BYTE*)p_MessageBoxA, (BYTE*)stub_MessageBoxA, MAX_COPY_SIZE );
	WriteJump( &stub_MessageBoxA[copied], (DWORD)p_MessageBoxA + copied );
}

void EndAPI()
{
	VirtualFree( stub_MessageBoxA, 0, MEM_RELEASE );
	FreeLibrary( hUser );
}

#undef MessageBox
#define MessageBox ((f_MessageBox)(stub_MessageBoxA))

int main()
{
	InitAPI();

	const char *title = "title", *msg = "message";
	MessageBox(NULL, msg, title, MB_OK);

	EndAPI();
	return 0;
}