
#include <windows.h>
#include <iostream>
#include <memory>

#include "APICaller.h"

using namespace std;
using namespace APICALLER;

int main()
{
	// initialize & check allocation error
	try {
// If you run on multithread, define MTHREAD on project option
#ifdef MTHREAD
		APILoader::Instance().InitInstance();
#endif
		if ( !APILoader::Instance().LoadDLL() ) {
			cout << "error: Loading DLL" << endl;
			return -1;
		}
		if ( !APILoader::Instance().InitAPITable() ) {
			cout << "error: Initialize API Address Table" << endl;
			return -1;
		}
	} catch ( bad_alloc ) {
		cout << "error: memory allocation" << endl;
		return -1;
	}

	MessageBox( NULL, "title", "message", MB_OK );



#ifdef MTHREAD
	APILoader::Instance().RemoveInstance();
#endif

	return 0;
}
