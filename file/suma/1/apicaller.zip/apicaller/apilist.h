
namespace APICALLER
{

// API Name��sizeof(TCHAR)*32�o�C�g�ȉ���
#define APILOADER_DLLNAMELEN 16

static const char *apiloader_dll[] =
{
	// "kernel32.dll",
	"user32.dll",
};

struct {
	unsigned int hash;
} loadapilist[] = {
	{ 0xD90916DC },		// MessageBoxA: 0xD90916DC
};



};	// namespace