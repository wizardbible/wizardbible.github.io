// written by KASHIHARA Shuzo


#include <map>

namespace APICALLER
{

#define ENCADDR(addr,k1) ((DWORD_PTR)(addr) ^ (DWORD_PTR)(k1))
#define DECADDR(addr,k1) ((DWORD_PTR)(addr) ^ (DWORD_PTR)(k1))

typedef struct _APIAddress
{
	DWORD_PTR buf[2];
} APIAddress;

typedef std::map<unsigned int, DWORD_PTR> APIList;

class APILoader
{
private:

#ifdef MTHREAD
	static APILoader *m_instance;
#endif

	HINSTANCE *m_hLibraryTbl;
	APIAddress *m_addrtbl;

public:

	static APILoader & Instance();

	~APILoader();

#ifdef MTHREAD
	void InitInstance();
	void RemoveInstance();
#endif

	inline DWORD_PTR GetAddress(int index)
	{
		APIAddress *addr = &m_addrtbl[index];
		return DECADDR( addr->buf[0], addr->buf[1] );
	}

	bool LoadDLL();
	bool InitAPITable();

private:

	APILoader();

	void AddAPI(HINSTANCE hLib, APIList &apilist);

};

};	// namespace