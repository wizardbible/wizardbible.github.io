
#include <cstdio>
#include <cstring>
#include "hash.h"

using namespace std;

int main(int argc, char *argv[])
{
	if ( argc != 2 ) {
		printf( "usage: hashstr string\n" );
		return -1;
	}
	char *str = argv[1];
	printf( "%s: 0x%8X\n", str, calchash(reinterpret_cast<unsigned char*>(str), strlen(str)) );

	return 0;
}
