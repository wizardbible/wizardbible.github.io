
namespace APICALLER
{

static unsigned int calchash(const unsigned char *buf, unsigned int len)
{
	unsigned int i, hash = 0x40506070, tmp = 0x12345678;
	for (i = 0; i < len; i++) {
		hash = (hash << 2) ^ (hash >> 2) - tmp;
		hash ^= buf[i];
		tmp += buf[i];
	}
	return hash;
}


};	// namespace