
typedef int (WINAPI *_MessageBoxA)(HWND, LPCTSTR, LPCTSTR, UINT);
#undef MessageBox
#define MessageBox ((_MessageBoxA)(APILoader::Instance().GetAddress(0)))

