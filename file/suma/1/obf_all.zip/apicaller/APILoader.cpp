// written by KASHIHARA Shuzo

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <time.h>

#include "APILoader.h"
#include "hash.h"

#include "apilist.h"

#undef MakePtr
#define MakePtr(cast, base, offset) (cast)((DWORD_PTR)(base) + (DWORD_PTR)(offset))
#define NTH(hLib) (PIMAGE_NT_HEADERS(LPBYTE(hLib) + PIMAGE_DOS_HEADER(hLib)->e_lfanew))
#define RVA(hLib) (NTH(hLib)->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress)
#define EXPDIR(hLib) (MakePtr(PIMAGE_EXPORT_DIRECTORY, hLib, RVA(hLib)))
#define ADDRTBL(hLib) (MakePtr(LPDWORD, hLib, EXPDIR(hLib)->AddressOfFunctions))
#define ORDNTBL(hLib) (MakePtr(LPWORD, hLib, EXPDIR(hLib)->AddressOfNameOrdinals))

#define SIZEARRAY(s) (sizeof(s)/sizeof(s[0]))

using namespace std;

namespace APICALLER
{

#ifdef MTHREAD
APILoader *APILoader::m_instance = NULL;
#endif

APILoader::APILoader()
{
	// allocate API Address Table
	m_addrtbl = new APIAddress[ SIZEARRAY(loadapilist) ];
	memset( m_addrtbl, 0, sizeof(APIAddress) * SIZEARRAY(loadapilist) );

	// allocate Instance Table
	m_hLibraryTbl = new HINSTANCE [ SIZEARRAY(m_hLibraryTbl) ];
	memset( m_addrtbl, 0, sizeof(HINSTANCE) * SIZEARRAY(m_hLibraryTbl) );
}

APILoader::~APILoader()
{
	for ( int index_lib = 0; index_lib < SIZEARRAY(m_hLibraryTbl); index_lib++ ) {
		if ( m_hLibraryTbl[index_lib] ) {
			FreeLibrary( m_hLibraryTbl[index_lib] );
		}
	}

	delete [] m_addrtbl;
	m_addrtbl = NULL;

	delete [] m_hLibraryTbl;
	m_hLibraryTbl = NULL;
}

#ifdef MTHREAD

void APILoader::InitInstance()
{
	if ( m_instance == NULL ) {
		m_instance = new APILoader;
	}
}

void APILoader::RemoveInstance()
{
	delete m_instance;
	m_instance = NULL;
}

#endif

APILoader & APILoader::Instance()
{
#ifndef MTHREAD
	static APILoader instance;
	return instance;
#else
	return *m_instance;
#endif
}

bool APILoader::LoadDLL()
{
	// get SystemDirectory
	TCHAR systemdir[MAX_PATH + APILOADER_DLLNAMELEN];
	UINT len = GetSystemDirectory( systemdir, MAX_PATH );
	if ( !len ) {
		return false;
	}

	// load Library from SystemDirectory
	for ( int index_lib = 0; index_lib < SIZEARRAY(m_hLibraryTbl); index_lib++ ) {
		systemdir[len] = TEXT( '\\' );
		lstrcpyn( systemdir + len + 1, apiloader_dll[index_lib], MAX_PATH + APILOADER_DLLNAMELEN - len );
		HINSTANCE hLib = LoadLibraryEx( systemdir, NULL, LOAD_WITH_ALTERED_SEARCH_PATH );
		if ( hLib == NULL ) {
			return false;
		}
		m_hLibraryTbl[index_lib] = hLib;
	}

	return true;
}

bool APILoader::InitAPITable()
{
	APIList apilist;

	// build APIList
	int index_lib, libnum = SIZEARRAY(m_hLibraryTbl);
	for ( index_lib = 0; index_lib < libnum; index_lib++ ) {
		AddAPI( m_hLibraryTbl[index_lib], apilist );
	}

	// get API Address
	srand( time(0) );
	for ( int index_apilist = 0; index_apilist < SIZEARRAY(loadapilist); index_apilist++ ) {
		APIList::iterator api_itr = apilist.find( loadapilist[index_apilist].hash );
		if ( api_itr != apilist.end() ) {
			unsigned int key = rand();
			m_addrtbl[index_apilist].buf[0] = ENCADDR( (*api_itr).second, key );
			m_addrtbl[index_apilist].buf[1] = key;
		} else {
			return false;
		}
	}

	return true;
}

void APILoader::AddAPI(HINSTANCE hLib, APIList &apilist)
{
	// Export Address Table
	LPDWORD eat = MakePtr( LPDWORD, hLib, EXPDIR(hLib)->AddressOfFunctions );
	// Export Ordinal Table
	LPWORD  eot = MakePtr(  LPWORD, hLib, EXPDIR(hLib)->AddressOfNameOrdinals );
	// Export Name Table
	LPDWORD ent = MakePtr( LPDWORD, hLib, EXPDIR(hLib)->AddressOfNames );

	for ( int index_addr = 0; index_addr < static_cast<int>(EXPDIR(hLib)->NumberOfNames); index_addr++ ) {
		char *str = MakePtr( char*, hLib, ent[index_addr] );
		unsigned int hash = calchash( reinterpret_cast<unsigned char*>(str), strlen(str) );
		DWORD_PTR    addr = MakePtr( DWORD_PTR, hLib, eat[eot[index_addr]] );
		apilist.insert( pair<unsigned int, DWORD_PTR>(hash, addr) );
	}
}

};	// namespace