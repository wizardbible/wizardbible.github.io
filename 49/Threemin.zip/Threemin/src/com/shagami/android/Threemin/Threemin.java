package com.shagami.android.Threemin;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Threemin extends Activity implements OnClickListener {
	public static final int TIMECOUNT = 1000 * 60 * 3;		// 1000ms * 60sec * 3min
	public static final int TIMERATE  = 500;				// 1000ms * 60sec * 3min
	public static final String STAT_START = "Start";
	public static final String STAT_STOP  = "Stop";
	public static final String STAT_TIMEUP  = "TimeUp";
	public static final String STAT_RESET = "Reset";

	private boolean mCountUp = false;
	private long    mTimeCount;
	private ScheduledExecutorService service;
	private Handler handler = new Handler();
	private Button mButton;
	private Date mDate;
	private String mStatus;
	private SimpleDateFormat mDateFormat;
	private SoundPool mSp;
	private int mStreamID;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.main);

        mDate = new Date(TIMECOUNT);
        mDateFormat = new SimpleDateFormat("mm:ss");

        mStatus = STAT_START;
        mButton = (Button) findViewById(R.id.Button01);
        mButton.setText(mStatus + "\n"+mDateFormat.format(mDate));
        mButton.setTextSize(48);
        mButton.setOnClickListener(this);

        mSp = new SoundPool (20, AudioManager.STREAM_MUSIC, 100 );
        mStreamID = mSp.load(getApplicationContext(), R.raw.timeup, 1 );
		mSp.setLoop(mStreamID, -1);		// loop forever...
    }

    public void onDestroy() {
		try {
			service.shutdown();
			mSp.stop(mStreamID);
		} catch ( Exception e) {
		}
		super.onDestroy();
    }

    public void onPause() {
		try {
			service.shutdown();
			mSp.stop(mStreamID);

			long now = SystemClock.currentThreadTimeMillis();
			SharedPreferences pm = PreferenceManager.getDefaultSharedPreferences(this);
Log.d("onPause","pm:"+pm.getAll().toString());
			Editor editor = pm.edit();
			editor.putLong("pausedTime", now);
			editor.putLong("timeCount", mTimeCount);
			editor.putString("nowStatus", mStatus);
			editor.commit();
Log.d("onPause","pm:"+pm.getAll().toString());
		} catch ( Exception e) {
		}
		super.onPause();
    }

    public void onResume() {
        super.onResume();

        mSp.stop(mStreamID);

        long now = SystemClock.currentThreadTimeMillis();
		SharedPreferences pm = PreferenceManager.getDefaultSharedPreferences(this);

Log.d("onResume","pm:"+pm.getAll().toString());


		long pt = pm.getLong("pausedTime", -1);
		long tc = pm.getLong("timeCount", -1);
		String st = pm.getString("nowStatus", STAT_START);
		long sub = now - pt;

Log.d("onResume","pt:"+pt+"/tc:"+tc+"/now:"+now+"/sub:"+sub);

		if ( pt > 0 && tc > 0 && sub > 0 && sub < tc && st == STAT_STOP ) {
				mStatus = STAT_STOP;
				mTimeCount = tc - sub;

				mDate.setTime(mTimeCount);

Log.d("onResume","pt:"+pt+"/tc:"+mTimeCount+"/now:"+now+"/sub:"+sub);

				service = Executors.newSingleThreadScheduledExecutor();
				service.scheduleAtFixedRate(new ClockWork(), 0, TIMERATE, TimeUnit.MILLISECONDS);
		} else {
			mStatus = STAT_START;
			mDate.setTime(TIMECOUNT);
		}
        mButton.setText(mStatus + "\n"+mDateFormat.format(mDate));
   }

	public void onClick(View arg0) {
		try {
			service.shutdown();
		} catch ( Exception e) {
		}

		if ( mStatus == STAT_START) {
			mCountUp   = false;
			mTimeCount = TIMECOUNT;
			mDate.setTime(mTimeCount);
			mStatus    = STAT_STOP;

	        service = Executors.newSingleThreadScheduledExecutor();
			service.scheduleAtFixedRate(new ClockWork(), 0, TIMERATE, TimeUnit.MILLISECONDS);
		} else if ( mStatus == STAT_STOP) {
			mStatus  = STAT_RESET;
		} else if ( mStatus == STAT_RESET || mStatus == STAT_TIMEUP) {
			mSp.stop(mStreamID);
	        mStatus = STAT_START;
			mDate.setTime(TIMECOUNT);
		}

		mButton.setText(mStatus + "\n" + mDateFormat.format(mDate));
	}

	public void playSound () {
		AudioManager mgr    = (AudioManager)getApplicationContext().getSystemService(Context.AUDIO_SERVICE);
		float currentVolume = mgr.getStreamVolume(AudioManager.STREAM_MUSIC);
		float maxVolume     = mgr.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
		float localVolume   = currentVolume / maxVolume;

		mSp.play(mStreamID, localVolume, localVolume, 1, 0, 1.0f);
	}

	private class DisplayCount implements Runnable {
		public void run() {
			mButton.setText(mStatus + "\n" + mDateFormat.format(mDate));
		}
	}

	private class ClockWork implements Runnable {

		public void run() {
			if ( mTimeCount > 0 ) {
				mTimeCount -= TIMERATE;
			}

			if ( mTimeCount <= 0 ) {
				mTimeCount = 0;
				if ( mCountUp == false ) {
					mCountUp = true;
					mStatus = STAT_TIMEUP;
					playSound();
				}
			}

			mDate.setTime(mTimeCount);
			handler.post(new DisplayCount());
		}
	}
}